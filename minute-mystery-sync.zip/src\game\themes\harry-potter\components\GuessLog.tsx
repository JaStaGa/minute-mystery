export { default } from '@/game/components/GuessLogHP';
