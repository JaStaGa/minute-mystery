import type { Character } from "@/game/types";
export type HPDetail = Character & { actor?: string | null };
